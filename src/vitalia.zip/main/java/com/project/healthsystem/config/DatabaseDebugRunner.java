package com.project.healthsystem.config;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;

@Component
@RequiredArgsConstructor
public class DatabaseDebugRunner implements CommandLineRunner {

    private final DataSource dataSource;

    @Override
    public void run(String... args) throws Exception {

        try (Connection conn = dataSource.getConnection()) {

            System.out.println("================================");
            System.out.println("URL: " + conn.getMetaData().getURL());
            System.out.println("USER: " + conn.getMetaData().getUserName());
            System.out.println("DATABASE: " + conn.getCatalog());
            System.out.println("================================");
        }
    }
}
