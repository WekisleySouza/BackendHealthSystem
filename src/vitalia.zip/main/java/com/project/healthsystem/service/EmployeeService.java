package com.project.healthsystem.service;

import com.project.healthsystem.controller.dto.basic_requests.EmployeeRequestDTO;
import com.project.healthsystem.controller.dto.basic_responses.EmployeeResponseDTO;
import com.project.healthsystem.controller.dto.simplified_info.EmployeeSimplifiedResponseDTO;
import com.project.healthsystem.controller.mappers.EmployeeMapper;
import com.project.healthsystem.controller.mappers.PersonMapper;
import com.project.healthsystem.model.Employee;
import com.project.healthsystem.model.Person;
import com.project.healthsystem.model.Roles;
import com.project.healthsystem.repository.EmployeeRepository;
import com.project.healthsystem.repository.specs.EmployeeSpecs;
import com.project.healthsystem.repository.specs.SpecsCommon;
import com.project.healthsystem.security.JwtTokenProvider;
import com.project.healthsystem.validator.EmployeeValidator;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
public class EmployeeService {
    private final EmployeeRepository repository;
    private final EmployeeValidator employeeValidator;
    private final EmployeeMapper employeeMapper;
    private final PersonMapper personMapper;

    private final LoginService loginService;
    private final PersonService personService;
    private final RoleService roleService;

    private final JwtTokenProvider jwtTokenProvider;

    @Transactional
    public Employee save(EmployeeRequestDTO employeeRequestDTO, String token){
        Employee employee = employeeValidator.validateSave(employeeRequestDTO);

        // Auditory
        Person currentEditor = jwtTokenProvider.getPerson(token);
        employee.createdNow();
        employee.setCreatedBy(currentEditor);
        employee.setLastModifiedBy(currentEditor);

        // Save Person
        if(!employeeRequestDTO.getCpfNormalized().isBlank() && personService.existsPersonByCpf(employeeRequestDTO.getCpfNormalized())){
            Person person = personService.getReferenceByCpf(employeeRequestDTO.getCpfNormalized());
            for(String role : employeeRequestDTO.getRoles()){
                person.addRole(roleService.findByRole(Roles.fromLabel(role)));
            }
            employee.setPerson(person);
        } else {
            Person person = personMapper.toPersonEntity(employeeRequestDTO);
            person.addRole(roleService.findByRole(Roles.PATIENT));
            for(String role : employeeRequestDTO.getRoles()){
                person.addRole(roleService.findByRole(Roles.fromLabel(role)));
            }
            person.setCreatedBy(currentEditor);
            person.setLastModifiedBy(currentEditor);
            person.createdNow();
            Person savedPerson = personService.save(person);

            employee.setPerson(savedPerson);
        }

        employee = repository.save(employee);
        loginService.createDefaultLoginTo(employee);
        return employee;
    }

    @Transactional
    public void update(EmployeeRequestDTO employeeRequestDTO, long id, String token){
        var employee = employeeValidator.validateUpdate(employeeRequestDTO, id);

        // Auditory
        Person currentEditor = jwtTokenProvider.getPerson(token);
        employee.setLastModifiedBy(currentEditor);
        employee.updatedNow();

        // Saving Person
        Person person = employee.getPerson();
        person = personMapper.updatePersonEntity(person, employeeRequestDTO);
        person.removeRole(Roles.EMPLOYEE)
            .removeRole(Roles.MANAGER)
            .removeRole(Roles.ADMIN);
        for(String role : employeeRequestDTO.getRoles()){
            person.addRole(roleService.findByRole(Roles.fromLabel(role)));
        }
        person.updatedNow();
        person.setLastModifiedBy(currentEditor);
        person = personService.save(person);

        employee.setPerson(person);
        repository.save(employee);
    }

    public EmployeeResponseDTO findById(long id){
        Employee employee = employeeValidator.validateFindById(id);
        return employeeMapper.toDto(employee);
    }

    public Employee findByCpf(String cpf) {
        return employeeValidator.validateFindByCpf(cpf);
    }

    public Page<EmployeeSimplifiedResponseDTO> getAllSimplified(
            Integer pageNumber,
            Integer pageLength
    ){
        Sort sort = Sort.by("person.name").ascending();
        Pageable pageRequest = PageRequest.of(pageNumber, pageLength, sort);
        return repository
            .findAll(pageRequest)
            .map(projection -> new EmployeeSimplifiedResponseDTO(
                projection.getId(),
                projection.getPerson().getName()
            ));
    }

    public Page<EmployeeResponseDTO> getAll(
            Integer pageNumber,
            Integer pageLength,
            String name,
            String gender,
            String cpf,
            LocalDate birthday,
            String email,
            String sex,
            String cellPhone,
            String residentialPhone,
            String contactPhone
    ){
        Sort sort = Sort.by("person.name").ascending();
        Pageable pageRequest = PageRequest.of(pageNumber, pageLength, sort);
        Specification<Employee> specs = null;
        specs = SpecsCommon.addSpec(specs, EmployeeSpecs.nameLike(name));
        specs = SpecsCommon.addSpec(specs, EmployeeSpecs.genderEqual(gender));
        specs = SpecsCommon.addSpec(specs, EmployeeSpecs.cpfLike(cpf));
        specs = SpecsCommon.addSpec(specs, EmployeeSpecs.birthdayEqual(birthday));
        specs = SpecsCommon.addSpec(specs, EmployeeSpecs.emailLike(email));
        specs = SpecsCommon.addSpec(specs, EmployeeSpecs.sexEqual(sex));
        specs = SpecsCommon.addSpec(specs, EmployeeSpecs.cellPhoneLike(cellPhone));
        specs = SpecsCommon.addSpec(specs, EmployeeSpecs.residentialPhoneLike(residentialPhone));
        specs = SpecsCommon.addSpec(specs, EmployeeSpecs.contactPhoneLike(contactPhone));
        return repository
            .findAll(specs, pageRequest)
            .map(employeeMapper::toDto);
    }

    @Transactional
    public void delete(long id){
        Employee employee = employeeValidator.validateDelete(id);

        // Removing role
        Person person = employee.getPerson();
        person.removeRole(Roles.EMPLOYEE)
            .removeRole(Roles.MANAGER)
            .removeRole(Roles.ADMIN);
        personService.save(person);

        repository.delete(employee);
    }
}
