package com.project.healthsystem.service;

import com.project.healthsystem.controller.dto.basic_requests.ProfessionalRequestDTO;
import com.project.healthsystem.controller.dto.basic_responses.ProfessionalResponseDTO;
import com.project.healthsystem.controller.dto.simplified_info.ProfessionalSimplifiedResponseDTO;
import com.project.healthsystem.controller.mappers.PersonMapper;
import com.project.healthsystem.controller.mappers.ProfessionalMapper;
import com.project.healthsystem.model.*;
import com.project.healthsystem.repository.ProfessionalRepository;
import com.project.healthsystem.repository.specs.ProfessionalSpecs;
import com.project.healthsystem.repository.specs.SpecsCommon;
import com.project.healthsystem.security.JwtTokenProvider;
import com.project.healthsystem.validator.ProfessionalValidator;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
public class ProfessionalService {

    private final ProfessionalRepository repository;
    private final ProfessionalValidator professionalValidator;
    private final ProfessionalMapper professionalMapper;
    private final PersonMapper personMapper;
    private final PersonService personService;
    private final RoleService roleService;

    private final JwtTokenProvider jwtTokenProvider;

    @Transactional
    public Professional save(ProfessionalRequestDTO professionalRequestDTO, String token){
        Professional professional = professionalValidator.validateSave(professionalRequestDTO);

        // Auditory data setting
        Person currentEditor = jwtTokenProvider.getPerson(token);
        professional.createdNow();
        professional.setCreatedBy(currentEditor);
        professional.setLastModifiedBy(currentEditor);

        if(!professionalRequestDTO.getCpfNormalized().isBlank() && personService.existsPersonByCpf(professionalRequestDTO.getCpfNormalized())){

            Person person = personService.getReferenceByCpf(professionalRequestDTO.getCpfNormalized());
            professional.setPerson(person);
        } else {
            Person person = personMapper.toPersonEntity(professionalRequestDTO);
            person.addRole(roleService.findByRole(Roles.PATIENT));
            person.setCreatedBy(currentEditor);
            person.setLastModifiedBy(currentEditor);
            person.createdNow();
            Person savedPerson = personService.save(person);

            professional.setPerson(savedPerson);
        }

        return repository.save(professional);
    }

    @Transactional
    public void update(ProfessionalRequestDTO professionalRequestDTO, long id, String token){
        Professional professional = professionalValidator.validateUpdate(professionalRequestDTO, id);

        // Auditory
        Person currentEditor = jwtTokenProvider.getPerson(token);
        professional.setLastModifiedBy(currentEditor);
        professional.updatedNow();

        // Saving Person
        Person person = professional.getPerson();
        person = personMapper.updatePersonEntity(person, professionalRequestDTO);
        person.updatedNow();
        person.setLastModifiedBy(currentEditor);
        person = personService.save(person);

        professional.setPerson(person);
        repository.save(professional);
    }

    public Page<ProfessionalSimplifiedResponseDTO> getAllSimplified(
            Integer pageNumber,
            Integer pageLength
    ){
        Sort sort = Sort.by("person.name").ascending();
        Pageable pageRequest = PageRequest.of(pageNumber, pageLength, sort);
        return repository
            .getAllBy(pageRequest)
            .map(projection -> new ProfessionalSimplifiedResponseDTO(
                projection.getId(),
                projection.getPerson().getName()
            ));
    }

    public Page<ProfessionalResponseDTO> getAll(
            Integer pageNumber,
            Integer pageLength,
            String name,
            String gender,
            String cpf,
            LocalDate birthday,
            String email,
            String sex,
            String cellPhone,
            String residentialPhone,
            String contactPhone,
            String cns,
            String cbo,
            String vinculation,
            String description
    ){
        Sort sort = Sort.by("person.name").ascending();
        Pageable pageRequest = PageRequest.of(pageNumber, pageLength, sort);
        Specification<Professional> specs = null;
        specs = SpecsCommon.addSpec(specs, ProfessionalSpecs.nameLike(name));
        specs = SpecsCommon.addSpec(specs, ProfessionalSpecs.genderEqual(gender));
        specs = SpecsCommon.addSpec(specs, ProfessionalSpecs.cpfLike(cpf));
        specs = SpecsCommon.addSpec(specs, ProfessionalSpecs.birthdayEqual(birthday));
        specs = SpecsCommon.addSpec(specs, ProfessionalSpecs.emailLike(email));
        specs = SpecsCommon.addSpec(specs, ProfessionalSpecs.sexEqual(sex));
        specs = SpecsCommon.addSpec(specs, ProfessionalSpecs.cellPhoneLike(cellPhone));
        specs = SpecsCommon.addSpec(specs, ProfessionalSpecs.residentialPhoneLike(residentialPhone));
        specs = SpecsCommon.addSpec(specs, ProfessionalSpecs.contactPhoneLike(contactPhone));
        specs = SpecsCommon.addSpec(specs, ProfessionalSpecs.cnsLike(cns));
        specs = SpecsCommon.addSpec(specs, ProfessionalSpecs.cboLike(cbo));
        specs = SpecsCommon.addSpec(specs, ProfessionalSpecs.descriptionLike(description));
        specs = SpecsCommon.addSpec(specs, ProfessionalSpecs.vinculationLike(vinculation));
        return repository
            .findAll(specs, pageRequest)
            .map(professionalMapper::toDto);
    }

    public ProfessionalResponseDTO findById(long id){
        Professional professional = professionalValidator.validateFindById(id);
        return professionalMapper.toDto(professional);
    }

    public void delete(long id){
        Professional professional = professionalValidator.validateDelete(id);
        repository.delete(professional);
    }
}
