package com.project.healthsystem.model;

import com.project.healthsystem.model.abstractions.BasicEntityAbstraction;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Entity
@Table(name = "tb_service_type")
@Data
@NoArgsConstructor
public class ServiceType extends BasicEntityAbstraction {
    @OneToMany(mappedBy = "serviceType")
    private List<Appointment> appointment;
    @ManyToOne
    private CategoryGroup categoryGroup;

    @Column(name = "sigtap_code")
    private String sigtapCode;
    @Column(name = "name", nullable = false)
    private String name;
    @Column(name = "value", precision = 20, scale = 8)
    private BigDecimal value;
    @Enumerated(EnumType.STRING)
    @Column(name = "type")
    private ServiceTypes type;

    public long getCategoryGroupId(){
        if(this.categoryGroup != null){
            return  this.categoryGroup.getId();
        }
        return -1;
    }

    public String getCategoryGroupName(){
        if (this.categoryGroup != null){
            return this.categoryGroup.getName();
        }
        return "";
    }
}
