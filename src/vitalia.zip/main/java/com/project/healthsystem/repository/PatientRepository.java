package com.project.healthsystem.repository;

import com.project.healthsystem.model.Patient;
import com.project.healthsystem.repository.projections.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Optional;

public interface PatientRepository extends JpaRepository<Patient, Long>, JpaSpecificationExecutor<Patient> {

    Page<com.project.healthsystem.repository.projections.simplified_lists.PatientSimplifiedInfoProjection> getAllBy(Pageable page);

    List<PatientSimplifiedInfoProjection> findAllBy();

    Optional<PatientInfoResponsibleProjection> findResponsibleById(long patientId);

    Optional<PatientInfoAgentProjection> findAgentById(long patientId);

    Optional<PatientInfoConditionsProjection> findConditionsById(long patientId);


    List<Patient> findByPersonCpf(String cpf);

    List<Patient> findByCns(String cns);
    
    List<Patient> findByPersonName(String name);

    boolean existsByPersonCpf(String cpf);


}
