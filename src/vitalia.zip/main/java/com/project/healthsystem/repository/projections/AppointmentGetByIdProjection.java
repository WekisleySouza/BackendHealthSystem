package com.project.healthsystem.repository.projections;

import com.project.healthsystem.model.Agreements;
import com.project.healthsystem.model.Priority;
import com.project.healthsystem.model.ServiceTypes;
import com.project.healthsystem.model.Status;
import org.springframework.beans.factory.annotation.Value;

import java.time.LocalDateTime;

public interface AppointmentGetByIdProjection {

    long getId();
    Status getStatus();
    Agreements getAgreements();
    String getNotes();
    Priority getPriorit();
    boolean getIsReturn();
    LocalDateTime getScheduledAt();
    LocalDateTime getCreatedAt();
    LocalDateTime getSchedulingForecast();

    ServiceTypeInfo getServiceType();
    ProfessionalInfo getResponsibleProfessional();
    ProfessionalInfo getRequestingProfessional();
    InstituitionInfo getInstituition();
    EmployeeInfo getEmployee();
    PatientInfo getPatient();

    default Long getResponsibleProfessionalIdSafe(){
        return getResponsibleProfessional() != null
            ? getResponsibleProfessional().getId()
            : null;
    }

    default String getResponsibleProfessionalNameSafe(){
        return getResponsibleProfessional() != null
            ? getResponsibleProfessional().getPerson() != null
              ? getResponsibleProfessional().getPerson().getName()
              : null
            : null;
    }

    default Long getRequestingProfessionalIdSafe(){
        return getRequestingProfessional() != null
            ? getRequestingProfessional().getId()
            : null;
    }

    default String getRequestingProfessionalNameSafe(){
        return getRequestingProfessional() != null
            ? getRequestingProfessional().getPerson() != null
                ? getRequestingProfessional().getPerson().getName()
                : null
            : null;
    }

    default Long getInstituitionIdSafe(){
        return getInstituition() != null
            ? getInstituition().getId()
            : null;
    }

    default String getInstituitionNameSafe(){
        return getInstituition() != null
            ? getInstituition().getName()
            : null;
    }

    interface InstituitionInfo {
        Long getId();
        String getName();
    }

    interface ServiceTypeInfo {
        long getId();
        String getName();
        ServiceTypes getType();
        @Value("#{target.categoryGroup != null ? target.categoryGroup.id : null}")
        Long getCategoryGroupId();
        @Value("#{target.categoryGroup != null ? target.categoryGroup.name : null}")
        String getCategoryGroupName();
    }

    interface ProfessionalInfo {
        long getId();
        PersonInfo getPerson();
    }

    interface EmployeeInfo {
        long getId();
        PersonInfo getPerson();
    }

    interface PatientInfo {
        long getId();
        PersonInfo getPerson();
    }

    interface PersonInfo {
        String getName();
    }
}
