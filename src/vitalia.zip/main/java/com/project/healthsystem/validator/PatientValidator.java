package com.project.healthsystem.validator;

import com.project.healthsystem.controller.dto.basic_requests.PatientRequestDTO;
import com.project.healthsystem.controller.mappers.PatientMapper;
import com.project.healthsystem.exceptions.DuplicatedRegisterException;
import com.project.healthsystem.exceptions.InvalidDataException;
import com.project.healthsystem.exceptions.NotFoundException;
import com.project.healthsystem.model.Agent;
import com.project.healthsystem.model.Condition;
import com.project.healthsystem.model.Patient;
import com.project.healthsystem.repository.AgentRepository;
import com.project.healthsystem.repository.PatientRepository;
import com.project.healthsystem.repository.projections.*;
import com.project.healthsystem.service.ConditionService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class PatientValidator {

    private final PatientRepository patientRepository;
    private final AgentRepository agentRepository;
    private final ConditionService conditionService;

    private final PatientMapper patientMapper;

    public Patient validateSave(PatientRequestDTO patientRequestDTO){
        if (!(patientRequestDTO.getCpfNormalized().isEmpty()) && patientRepository.existsByPersonCpf(patientRequestDTO.getCpfNormalized())){
            throw new DuplicatedRegisterException("Cpf já cadastrado!");
        }

        Patient patient = patientMapper.toEntity(patientRequestDTO);

        if(patientRequestDTO.getAgentId() != null && patientRequestDTO.getAgentId() != -1){
            Agent agent = agentRepository.findById(patientRequestDTO.getAgentId())
                .orElseThrow(() -> new InvalidDataException("Agent inválido!"));
            patient.setAgent(agent);
        }
        if(patientRequestDTO.getResponsibleId() != null){
            Patient responsible = patientRepository.findById(patientRequestDTO.getResponsibleId())
                .orElse(null);
            patient.setResponsible(responsible);
        }
        if(patientRequestDTO.getConditionsId() != null && !patientRequestDTO.getConditionsId().isEmpty()){
            List<Condition> conditions = conditionService.findByIds(patientRequestDTO.getConditionsId());
            patient.setConditions(conditions);
        }

        return patient;
    }

    public Patient validateUpdate(PatientRequestDTO patientRequestDTO, long id){
        Patient patient = patientRepository.findById(id)
            .orElseThrow(() -> new NotFoundException("Paciente não encontrada!"));
        Agent agent = agentRepository.findById(patientRequestDTO.getAgentId())
                .orElseThrow(() -> new InvalidDataException("Agent inválido!"));

        patient = patientMapper.toEntityWhenHasId(patient, patientRequestDTO);
        patient.setAgent(agent);

        if(patientRequestDTO.getResponsibleId() != null){
            Patient responsible = patientRepository.findById(patientRequestDTO.getResponsibleId())
                    .orElse(null);
            patient.setResponsible(responsible);
        }
        if(patientRequestDTO.getConditionsId() != null && !patientRequestDTO.getConditionsId().isEmpty()){
            List<Condition> conditions = conditionService.findByIds(patientRequestDTO.getConditionsId());
            patient.setConditions(conditions);
        }

        return patient;
    }

    public Patient validateFindById(long id){
        return patientRepository.findById(id)
            .orElseThrow(() -> new NotFoundException("Paciente não encontrado!"));
    }

    public PatientInfoResponsibleProjection validateFindResponsibleById(long id){
        return patientRepository.findResponsibleById(id)
            .orElseThrow(() -> new NotFoundException("Paciente não encontrado!"));
    }

    public PatientInfoAgentProjection validateFindAgentById(long id){
        return patientRepository.findAgentById(id)
            .orElseThrow(() -> new NotFoundException("Paciente não encontrado1!"));
    }

    public PatientInfoConditionsProjection validateFindConditionsById(long id){
        return patientRepository.findConditionsById(id)
            .orElseThrow(() -> new NotFoundException("Paciente não encontrado!"));
    }

    public Patient validateFindByCpf(String cpf){
        List<Patient> patient = patientRepository.findByPersonCpf(cpf);
        if (patient.isEmpty()){
            throw new NotFoundException("Paciente não encontrado!");
        }
        return patient.get(0);
    }

    public Patient validateDelete(long id){
        return patientRepository.findById(id)
            .orElseThrow(() -> new NotFoundException("Paciente não encontrada!"));
    }
}
