package com.project.healthsystem.controller.dto.basic_responses;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
public class ProfessionalResponseDTO {
    private long id;

    private String cns;
    private String cbo;
    private String vinculation;
    private String description;
    private String name;
    private String gender;
    private String sex;
    private String cellPhone;
    private String residentialPhone;
    private String contactPhone;
    private LocalDate birthday;
    private String cpf;
    private String address;
    private String email;
}
