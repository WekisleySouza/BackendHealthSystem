package com.project.healthsystem.controller.mappers;

import com.project.healthsystem.controller.dto.basic_requests.SurgeryTypeRequestDTO;
import com.project.healthsystem.controller.dto.basic_responses.SurgeryTypeResponseDTO;
import com.project.healthsystem.model.SurgeryType;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public abstract class SurgeryTypeMapper {

    public abstract SurgeryType toEntity(SurgeryTypeRequestDTO dto);

    public abstract SurgeryTypeResponseDTO toDto(SurgeryType entity);

    public SurgeryType toEntityWhenHasId(SurgeryType entity, SurgeryTypeRequestDTO dto){
        entity.setType(dto.getType());
        return entity;
    }
}
