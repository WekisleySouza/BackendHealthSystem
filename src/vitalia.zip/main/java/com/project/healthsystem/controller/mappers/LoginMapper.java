package com.project.healthsystem.controller.mappers;

import com.project.healthsystem.controller.dto.basic_requests.LoginRequestDTO;
import com.project.healthsystem.model.Login;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public abstract class LoginMapper {

    public abstract Login toEntity(LoginRequestDTO dto);

    public abstract LoginRequestDTO toDto(Login entity);

    public Login toEntityWhenHasId(Login entity, LoginRequestDTO dto){
        Login newEntity = toEntity(dto);
        newEntity.setId(entity.getId());
        return newEntity;
    }
}
